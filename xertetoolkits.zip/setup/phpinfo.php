<?PHP phpinfo();

?>