<html>
	<body>
		<form action="file_system_iframe.php">
			<input type="submit" value="Run file system test" />
		</form>
	</body>
</html>