<html>
	<body>
		<form action="mysql_iframe.php">
			<input type="submit" value="Run mysql test" />
		</form>
	</body>
</html>