<html>
	<head>
		<style>

			html{
	
				font-family:arial;

			}

		</style>

	</head>
	<body>
	Please enter the host, username and password you'll use for creating the toolkits database.<br>
<form action="mysql_iframe_4.php" method="POST">
Host <input type="text" name="host" size="50" /><br />
Username <input type="text" name="username" size="50" /><br />
Password <input type="password" name="password" size="50" /><br />
<input type="submit" value="Test connectivity" />
</form>
