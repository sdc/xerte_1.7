<html>
	<body>
		<form action="php_modules_iframe.php">
			<input type="submit" value="Run PHP module test" />
		</form>
	</body>
</html>