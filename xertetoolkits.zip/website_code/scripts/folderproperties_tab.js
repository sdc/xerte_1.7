	/**	
	 * 
	 * folderproperties, javascript for the folder properties tab
	 *
	 * @author Patrick Lockley
	 * @version 1.0
	 * @copyright Copyright (c) 2008,2009 University of Nottingham
	 * @package
	 */

	 /**
	 * 
	 * Function folders ajax send prepare
 	 * This function sorts out the URL for most of the queries in the folder properties window
	 * @param string url = the extra part of the url for this ajax query
	 * @version 1.0
	 * @author Patrick Lockley
	 */

function folders_ajax_send_prepare(url){

   	xmlHttp.open("post","website_code/php/folderproperties/" + url,true);
	xmlHttp.onreadystatechange=folder_properties_stateChanged;
	xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	
}

 	/**
	 * 
	 * Function folders properties state changed
 	 * This function handles all of the responses from the ajax queries
	 * @version 1.0
	 * @author Patrick Lockley
	 */

function folder_properties_stateChanged(){ 

	if (xmlHttp.readyState==4){ 
			
		if(xmlHttp.responseText!=""){
			
			document.getElementById('dynamic_area').innerHTML = xmlHttp.responseText;

		}
	}
} 

 	/**
	 * 
	 * Function folder name state changed
 	 * This function handles ajax responses for the folder rename query as this requires extra bits of work
	 * @version 1.0
	 * @author Patrick Lockley
	 */


function folder_rename_stateChanged(){ 

	if (xmlHttp.readyState==4){ 

		if(xmlHttp.responseText!=""){

			/*
			* the response contains the new html and the new file name, so split them
			*/

			array_response = xmlHttp.responseText.split("~*~");

			/*
			* set the html
			*/

			document.getElementById('dynamic_area').innerHTML = array_response[0];

			/*
			* prepare and change the folder name in the main window
			*/

			id = "folder_" + window.name.substr(0,window.name.indexOf("_"));

			current_innerHTML = window_reference.document.getElementById(id).childNodes[0].innerHTML;

			future_innerHTML = current_innerHTML.substr(0,current_innerHTML.lastIndexOf(">")+1) + array_response[1];

			window_reference.document.getElementById(id).childNodes[0].innerHTML = future_innerHTML;

	
		}
	}		

}

 /**
	 * 
	 * Function folders rss template
 	 * This function displays the RSS features for this folder
	 * @version 1.0
	 * @author Patrick Lockley
	 */

function folder_rss_template(){

	if(setup_ajax()!=false){
    
		var url="folder_rss_template.php";

		folders_ajax_send_prepare(url);

		xmlHttp.send('folder_id=' + window.name); 

	}

}

 /**
	 * 
	 * Function folders properties
 	 * This function displays the basic properties panel for this folder
	 * @version 1.0
	 * @author Patrick Lockley
	 */

function folderproperties_template(){

	if(setup_ajax()!=false){
    
		var url="folderproperties_template.php";

		folders_ajax_send_prepare(url);

		xmlHttp.send('folder_id=' + String(window.name).substr(0,String(window.name).indexOf("_"))); 

	}

}

 /**
	 * 
	 * Function folder content template
 	 * This function shows the content of this folder for the folder content tab
	 * @version 1.0
	 * @author Patrick Lockley
	 */


function folder_content_template(){

	if(setup_ajax()!=false){
    
		var url="folder_content_template.php";

		folders_ajax_send_prepare(url);

		xmlHttp.send('folder_id=' + String(window.name).substr(0,String(window.name).indexOf("_"))); 

	}

}

 /**  CHECK THIS - OBSOLETE?
	 * 
	 * Function folders ajax send prepare
 	 * This function sorts out the URL for most of the queries in the folder properties window
	 * @param string url = the extra part of the url for this ajax query
	 * @version 1.0
	 * @author Patrick Lockley
	 */


function folder_name_template_a(){

	if(setup_ajax()!=false){
    
		var url="folder_name_template.php";

		folders_ajax_send_prepare(url);

		xmlHttp.send('folder_id=' + window.name); 

	}

}

 	/**
	 * 
	 * Function rename folder
 	 * This function renames the folder
	 * @param string folder_id = the id of this folder
 	 * @param string form_tag = the the id of the form
	 * @version 1.0
	 * @author Patrick Lockley
	 */


function rename_folder(folder_id,form_tag){

	new_name = document.getElementById(form_tag).childNodes[0].value;

	if(is_ok_name(new_name)){

		if(setup_ajax()!=false){
    
			var url="rename_folder_template.php";

			xmlHttp.open("post","website_code/php/folderproperties/" + url,true);
			xmlHttp.onreadystatechange=folder_rename_stateChanged;
			xmlHttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

			xmlHttp.send('folder_id=' + folder_id +'&folder_name=' + new_name); 

		}

	}else{

		alert("Sorry that is not a valid name. Please use only numbers and letters");

	}

}