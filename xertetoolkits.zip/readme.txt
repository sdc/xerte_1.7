Here's a quick guide to installing toolkits on your local computer:

Download and install XAMPP from
http://www.apachefriends.org/download.php?xampp-win32-1.7.0-installer.exe accepting the default settings;

Download Xerte Online Toolkits from
http://www.nottingham.ac.uk/xerte/downloads/xertetoolkits.zip

Unzip the folder 'xertetoolkits' to c:\xampp\htdocs\, giving you
c:\xampp\htdocs\xertetoolkits

Start Apache and MySQL in XAMPP control panel

Visit http://localhost/xertetoolkits/setup

Click the XAMPP button.


There's a quick capture of the process here:

http://www.nottingham.ac.uk/xerte/manual/installingToolkits.swf


Server administrators should choose the 'full install' option and step
through the wizard. When copying the files to a server, you can use the setup utility at http://yourserver.com/yourtololkitsfolder/setup

See also : http://code.google.com/p/xerteonlinetoolkits/ 
