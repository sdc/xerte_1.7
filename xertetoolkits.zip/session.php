<?PHP /**
* 
* Session page, allows pages other than index.php to maintain the session
*
* @author Patrick Lockley
* @version 1.0
* @copyright Copyright (c) 2008,2009 University of Nottingham
* @package
*/

require_once("config.php");

